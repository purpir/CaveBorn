package ru.purpir.screen;

import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_9288;
import net.minecraft.class_9334;
import ru.purpir.item.ModItems;

public class BagScreenHandler extends class_1703 {
    private final class_1277 inventory;
    private final class_1799 bagStack;
    private final int bagSlotIndex;
    public static final int BAG_SLOTS = 18;

    public BagScreenHandler(int syncId, class_1661 playerInventory, class_1799 bagStack) {
        super(ModScreenHandlers.BAG_SCREEN_HANDLER, syncId);
        this.bagStack = bagStack;
        this.bagSlotIndex = playerInventory.method_67532();
        this.inventory = new class_1277(BAG_SLOTS) {
            @Override
            public void method_5431() {
                super.method_5431();
                saveToContainer();
            }
        };
        
        loadFromContainer();
        
        for (int row = 0; row < 2; row++) {
            for (int col = 0; col < 9; col++) {
                this.method_7621(new BagSlot(inventory, col + row * 9, 8 + col * 18, 18 + row * 18));
            }
        }

        // Player inventory
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.method_7621(new class_1735(playerInventory, col + row * 9 + 9, 8 + col * 18, 66 + row * 18));
            }
        }

        // Player hotbar
        for (int col = 0; col < 9; col++) {
            final int slotIndex = col;
            this.method_7621(new class_1735(playerInventory, col, 8 + col * 18, 124) {
                @Override
                public boolean method_7674(class_1657 player) {
                    return slotIndex != bagSlotIndex;
                }
                
                @Override
                public boolean method_7680(class_1799 stack) {
                    return slotIndex != bagSlotIndex;
                }
            });
        }
    }

    private void loadFromContainer() {
        class_9288 container = bagStack.method_58695(class_9334.field_49622, class_9288.field_49334);
        container.method_57492(inventory.method_54454());
    }

    private void saveToContainer() {
        bagStack.method_57379(class_9334.field_49622, class_9288.method_57493(inventory.method_54454()));
    }

    @Override
    public void method_7595(class_1657 player) {
        super.method_7595(player);
        saveToContainer();
    }

    @Override
    public class_1799 method_7601(class_1657 player, int slotIndex) {
        class_1799 newStack = class_1799.field_8037;
        class_1735 slot = this.field_7761.get(slotIndex);
        
        if (slot.method_7681()) {
            class_1799 originalStack = slot.method_7677();
            newStack = originalStack.method_7972();
            
            if (slotIndex < BAG_SLOTS) {
                if (!this.method_7616(originalStack, BAG_SLOTS, this.field_7761.size(), true)) {
                    return class_1799.field_8037;
                }
            } else {
                if (!this.method_7616(originalStack, 0, BAG_SLOTS, false)) {
                    return class_1799.field_8037;
                }
            }
            
            if (originalStack.method_7960()) {
                slot.method_53512(class_1799.field_8037);
            } else {
                slot.method_7668();
            }
        }
        
        return newStack;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return true;
    }

    private class BagSlot extends class_1735 {
        public BagSlot(class_1277 inventory, int index, int x, int y) {
            super(inventory, index, x, y);
        }

        @Override
        public boolean method_7680(class_1799 stack) {
            return !stack.method_31574(ModItems.BAG);
        }
    }
}
