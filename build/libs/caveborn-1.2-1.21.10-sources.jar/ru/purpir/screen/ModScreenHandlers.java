package ru.purpir.screen;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7701;
import net.minecraft.class_7923;
import ru.purpir.Caveborn;

public class ModScreenHandlers {
    public static final class_3917<BagScreenHandler> BAG_SCREEN_HANDLER = 
        class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Caveborn.MOD_ID, "bag"),
            new class_3917<>((syncId, playerInventory) -> 
                new BagScreenHandler(syncId, playerInventory, playerInventory.field_7546.method_6047()), 
                class_7701.field_40182));

    public static void register() {
        Caveborn.LOGGER.info("Registering Screen Handlers for " + Caveborn.MOD_ID);
    }
}
