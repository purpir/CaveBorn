package ru.purpir.network;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import ru.purpir.Caveborn;

public class ModPackets {
    
    public static final class_2960 OPEN_ALTAR_SCREEN = class_2960.method_60655(Caveborn.MOD_ID, "open_altar_screen");
    
    public record OpenAltarScreenPayload(int questLevel, int totalCompleted) implements class_8710 {
        public static final class_9154<OpenAltarScreenPayload> ID = new class_9154<>(OPEN_ALTAR_SCREEN);
        public static final class_9139<class_9129, OpenAltarScreenPayload> CODEC = class_9139.method_56435(
            class_9135.field_49675, OpenAltarScreenPayload::questLevel,
            class_9135.field_49675, OpenAltarScreenPayload::totalCompleted,
            OpenAltarScreenPayload::new
        );
        
        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }
    
    public static void registerServer() {
        PayloadTypeRegistry.playS2C().register(OpenAltarScreenPayload.ID, OpenAltarScreenPayload.CODEC);
    }
}
