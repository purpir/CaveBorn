package ru.purpir.client.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_7225;
import ru.purpir.block.ModBlocks;
import ru.purpir.item.ModItems;

import java.util.concurrent.CompletableFuture;

public class ModLootTableProvider extends FabricBlockLootTableProvider {
    public ModLootTableProvider(FabricDataOutput dataOutput, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataOutput, registryLookup);
    }

    @Override
    public void method_10379() {
        // Bronze ore drops raw bronze
        method_45988(ModBlocks.BRONZE_ORE, method_45981(ModBlocks.BRONZE_ORE, ModItems.RAW_BRONZE));
        method_46025(ModBlocks.BRONZE_BLOCK);

        // Titanium ore drops raw titanium
        method_45988(ModBlocks.TITANIUM_ORE, method_45981(ModBlocks.TITANIUM_ORE, ModItems.RAW_TITANIUM));
        method_45988(ModBlocks.DEEPSLATE_TITANIUM_ORE, method_45981(ModBlocks.DEEPSLATE_TITANIUM_ORE, ModItems.RAW_TITANIUM));
        method_46025(ModBlocks.TITANIUM_BLOCK);

        method_46025(ModBlocks.NETHERITE_TITANIUM_BLOCK);
        
        // Weed loot tables are defined manually in resources/data/caveborn/loot_table/blocks/
    }
}
