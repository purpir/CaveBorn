package ru.purpir.client.datagen;

import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import ru.purpir.Caveborn;

public class ModTags {
    public static class Blocks {
        public static final class_6862<class_2248> NEEDS_NETHERITE_TOOL = createTag("needs_netherite_tool");

        private static class_6862<class_2248> createTag(String name) {
            return class_6862.method_40092(class_7924.field_41254, class_2960.method_60655(Caveborn.MOD_ID, name));
        }
    }

    public static class Items {
        public static final class_6862<class_1792> BRONZE_INGOTS = createTag("bronze_ingots");
        public static final class_6862<class_1792> TITANIUM_INGOTS = createTag("titanium_ingots");

        private static class_6862<class_1792> createTag(String name) {
            return class_6862.method_40092(class_7924.field_41197, class_2960.method_60655(Caveborn.MOD_ID, name));
        }
    }
}
