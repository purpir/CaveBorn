package ru.purpir.client.datagen;

import net.fabricmc.fabric.api.client.datagen.v1.provider.FabricModelProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4943;
import ru.purpir.block.ModBlocks;
import ru.purpir.item.ModItems;

public class ModModelProvider extends FabricModelProvider {
    public ModModelProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator) {
        blockStateModelGenerator.method_25641(ModBlocks.BRONZE_ORE);
        blockStateModelGenerator.method_25641(ModBlocks.BRONZE_BLOCK);
        blockStateModelGenerator.method_25641(ModBlocks.TITANIUM_ORE);
        blockStateModelGenerator.method_25641(ModBlocks.DEEPSLATE_TITANIUM_ORE);
        blockStateModelGenerator.method_25641(ModBlocks.NETHERITE_TITANIUM_BLOCK);
        blockStateModelGenerator.method_25641(ModBlocks.VACUUMITE_ORE);
        blockStateModelGenerator.method_25641(ModBlocks.VACUUMITE_BLOCK);
        
        // Titanium building blocks - используем pool для titanium_block чтобы избежать дубликата
        class_4910.class_4912 titaniumPool = blockStateModelGenerator.method_25650(ModBlocks.TITANIUM_BLOCK);
        blockStateModelGenerator.method_25641(ModBlocks.TITANIUM_GRATE);
        titaniumPool.method_25725(ModBlocks.TITANIUM_STAIRS);
        titaniumPool.method_25724(ModBlocks.TITANIUM_SLAB);
        
        // Titanium bars - модели создаются вручную (см. resources/assets/caveborn/)
        blockStateModelGenerator.method_25658(ModBlocks.TITANIUM_DOOR);
        blockStateModelGenerator.method_25671(ModBlocks.TITANIUM_TRAPDOOR);
    }

    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {
        // Misc
        itemModelGenerator.method_65442(ModItems.FIBER, class_4943.field_22938);
        itemModelGenerator.method_65442(ModItems.BAG, class_4943.field_22938);
        
        itemModelGenerator.method_65442(ModItems.BRONZE_INGOT, class_4943.field_22938);
        itemModelGenerator.method_65442(ModItems.RAW_BRONZE, class_4943.field_22938);
        itemModelGenerator.method_65442(ModItems.BRONZE_SWORD, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.BRONZE_PICKAXE, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.BRONZE_AXE, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.BRONZE_SHOVEL, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.BRONZE_HOE, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.BRONZE_HELMET, class_4943.field_22938);
        itemModelGenerator.method_65442(ModItems.BRONZE_CHESTPLATE, class_4943.field_22938);
        itemModelGenerator.method_65442(ModItems.BRONZE_LEGGINGS, class_4943.field_22938);
        itemModelGenerator.method_65442(ModItems.BRONZE_BOOTS, class_4943.field_22938);

        itemModelGenerator.method_65442(ModItems.TITANIUM_INGOT, class_4943.field_22938);
        itemModelGenerator.method_65442(ModItems.RAW_TITANIUM, class_4943.field_22938);

        itemModelGenerator.method_65442(ModItems.VACUUMITE_INGOT, class_4943.field_22938);
        itemModelGenerator.method_65442(ModItems.RAW_VACUUMITE, class_4943.field_22938);

        itemModelGenerator.method_65442(ModItems.NETHERITE_TITANIUM_INGOT, class_4943.field_22938);
        itemModelGenerator.method_65442(ModItems.NETHERITE_TITANIUM_SWORD, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.NETHERITE_TITANIUM_PICKAXE, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.NETHERITE_TITANIUM_AXE, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.NETHERITE_TITANIUM_SHOVEL, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.NETHERITE_TITANIUM_HOE, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.NETHERITE_TITANIUM_HELMET, class_4943.field_22938);
        itemModelGenerator.method_65442(ModItems.NETHERITE_TITANIUM_CHESTPLATE, class_4943.field_22938);
        itemModelGenerator.method_65442(ModItems.NETHERITE_TITANIUM_LEGGINGS, class_4943.field_22938);
        itemModelGenerator.method_65442(ModItems.NETHERITE_TITANIUM_BOOTS, class_4943.field_22938);
    }
}
