package ru.purpir.client.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_3489;
import net.minecraft.class_7225;
import ru.purpir.item.ModItems;
import ru.purpir.item.ModTags;

import java.util.concurrent.CompletableFuture;

public class ModItemTagProvider extends FabricTagProvider.ItemTagProvider {
    public ModItemTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 wrapperLookup) {
        valueLookupBuilder(ModTags.Items.BRONZE_INGOTS)
            .method_71554(ModItems.BRONZE_INGOT);
        
        valueLookupBuilder(ModTags.Items.TITANIUM_INGOTS)
            .method_71554(ModItems.TITANIUM_INGOT);

        valueLookupBuilder(ModTags.Items.BRONZE_REPAIR)
            .method_71554(ModItems.BRONZE_INGOT);

        valueLookupBuilder(ModTags.Items.NETHERITE_TITANIUM_REPAIR)
            .method_71554(ModItems.NETHERITE_TITANIUM_INGOT);

        // Armor trims support
        valueLookupBuilder(class_3489.field_41890)
            .method_71554(ModItems.BRONZE_HELMET)
            .method_71554(ModItems.BRONZE_CHESTPLATE)
            .method_71554(ModItems.BRONZE_LEGGINGS)
            .method_71554(ModItems.BRONZE_BOOTS)
            .method_71554(ModItems.NETHERITE_TITANIUM_HELMET)
            .method_71554(ModItems.NETHERITE_TITANIUM_CHESTPLATE)
            .method_71554(ModItems.NETHERITE_TITANIUM_LEGGINGS)
            .method_71554(ModItems.NETHERITE_TITANIUM_BOOTS);

        // Hoes - чтобы работало вспахивание
        valueLookupBuilder(class_3489.field_42613)
            .method_71554(ModItems.BRONZE_HOE)
            .method_71554(ModItems.NETHERITE_TITANIUM_HOE);
    }
}
