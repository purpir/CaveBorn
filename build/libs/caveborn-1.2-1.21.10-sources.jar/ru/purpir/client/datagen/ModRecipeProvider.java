package ru.purpir.client.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_2446;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import ru.purpir.block.ModBlocks;
import ru.purpir.item.ModItems;

import java.util.concurrent.CompletableFuture;

public class ModRecipeProvider extends FabricRecipeProvider {
    public ModRecipeProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected class_2446 method_62766(class_7225.class_7874 registries, class_8790 exporter) {
        return new class_2446(registries, exporter) {
            @Override
            public void method_10419() {
                // Bronze smelting
                method_36233(java.util.List.of(ModItems.RAW_BRONZE), class_7800.field_40642, 
                    ModItems.BRONZE_INGOT, 0.7f, 200, "bronze");
                method_36234(java.util.List.of(ModItems.RAW_BRONZE), class_7800.field_40642, 
                    ModItems.BRONZE_INGOT, 0.7f, 100, "bronze");
                method_36233(java.util.List.of(ModBlocks.BRONZE_ORE), class_7800.field_40642, 
                    ModItems.BRONZE_INGOT, 0.7f, 200, "bronze");
                method_36234(java.util.List.of(ModBlocks.BRONZE_ORE), class_7800.field_40642, 
                    ModItems.BRONZE_INGOT, 0.7f, 100, "bronze");

                // Titanium smelting
                method_36233(java.util.List.of(ModItems.RAW_TITANIUM), class_7800.field_40642, 
                    ModItems.TITANIUM_INGOT, 1.0f, 200, "titanium");
                method_36234(java.util.List.of(ModItems.RAW_TITANIUM), class_7800.field_40642, 
                    ModItems.TITANIUM_INGOT, 1.0f, 100, "titanium");

                // Bronze block
                method_36325(class_7800.field_40634, 
                    ModItems.BRONZE_INGOT, class_7800.field_40635, ModBlocks.BRONZE_BLOCK);
                
                // Titanium block
                method_36325(class_7800.field_40634, 
                    ModItems.TITANIUM_INGOT, class_7800.field_40635, ModBlocks.TITANIUM_BLOCK);
                
                // Netherite Titanium block
                method_36325(class_7800.field_40634, 
                    ModItems.NETHERITE_TITANIUM_INGOT, class_7800.field_40635, ModBlocks.NETHERITE_TITANIUM_BLOCK);

                // Netherite Titanium Ingot - 4 netherite ingots + 4 titanium ingots
                method_62747(class_7800.field_40642, ModItems.NETHERITE_TITANIUM_INGOT, 1)
                    .method_10439("NTN")
                    .method_10439("TNT")
                    .method_10439("NTN")
                    .method_10434('N', class_1802.field_22020)
                    .method_10434('T', ModItems.TITANIUM_INGOT)
                    .method_10429(method_32807(class_1802.field_22020), method_10426(class_1802.field_22020))
                    .method_10429(method_32807(ModItems.TITANIUM_INGOT), method_10426(ModItems.TITANIUM_INGOT))
                    .method_36443(field_53721, "netherite_titanium_ingot_from_crafting");

                // Bronze Tools
                method_62746(class_7800.field_40638, ModItems.BRONZE_SWORD)
                    .method_10439("B").method_10439("B").method_10439("S")
                    .method_10434('B', ModItems.BRONZE_INGOT).method_10434('S', class_1802.field_8600)
                    .method_10429(method_32807(ModItems.BRONZE_INGOT), method_10426(ModItems.BRONZE_INGOT))
                    .method_10431(field_53721);

                method_62746(class_7800.field_40638, ModItems.BRONZE_PICKAXE)
                    .method_10439("BBB").method_10439(" S ").method_10439(" S ")
                    .method_10434('B', ModItems.BRONZE_INGOT).method_10434('S', class_1802.field_8600)
                    .method_10429(method_32807(ModItems.BRONZE_INGOT), method_10426(ModItems.BRONZE_INGOT))
                    .method_10431(field_53721);

                method_62746(class_7800.field_40638, ModItems.BRONZE_AXE)
                    .method_10439("BB").method_10439("BS").method_10439(" S")
                    .method_10434('B', ModItems.BRONZE_INGOT).method_10434('S', class_1802.field_8600)
                    .method_10429(method_32807(ModItems.BRONZE_INGOT), method_10426(ModItems.BRONZE_INGOT))
                    .method_10431(field_53721);

                method_62746(class_7800.field_40638, ModItems.BRONZE_SHOVEL)
                    .method_10439("B").method_10439("S").method_10439("S")
                    .method_10434('B', ModItems.BRONZE_INGOT).method_10434('S', class_1802.field_8600)
                    .method_10429(method_32807(ModItems.BRONZE_INGOT), method_10426(ModItems.BRONZE_INGOT))
                    .method_10431(field_53721);

                method_62746(class_7800.field_40638, ModItems.BRONZE_HOE)
                    .method_10439("BB").method_10439(" S").method_10439(" S")
                    .method_10434('B', ModItems.BRONZE_INGOT).method_10434('S', class_1802.field_8600)
                    .method_10429(method_32807(ModItems.BRONZE_INGOT), method_10426(ModItems.BRONZE_INGOT))
                    .method_10431(field_53721);

                // Bronze Armor
                method_62746(class_7800.field_40639, ModItems.BRONZE_HELMET)
                    .method_10439("BBB").method_10439("B B")
                    .method_10434('B', ModItems.BRONZE_INGOT)
                    .method_10429(method_32807(ModItems.BRONZE_INGOT), method_10426(ModItems.BRONZE_INGOT))
                    .method_10431(field_53721);

                method_62746(class_7800.field_40639, ModItems.BRONZE_CHESTPLATE)
                    .method_10439("B B").method_10439("BBB").method_10439("BBB")
                    .method_10434('B', ModItems.BRONZE_INGOT)
                    .method_10429(method_32807(ModItems.BRONZE_INGOT), method_10426(ModItems.BRONZE_INGOT))
                    .method_10431(field_53721);

                method_62746(class_7800.field_40639, ModItems.BRONZE_LEGGINGS)
                    .method_10439("BBB").method_10439("B B").method_10439("B B")
                    .method_10434('B', ModItems.BRONZE_INGOT)
                    .method_10429(method_32807(ModItems.BRONZE_INGOT), method_10426(ModItems.BRONZE_INGOT))
                    .method_10431(field_53721);

                method_62746(class_7800.field_40639, ModItems.BRONZE_BOOTS)
                    .method_10439("B B").method_10439("B B")
                    .method_10434('B', ModItems.BRONZE_INGOT)
                    .method_10429(method_32807(ModItems.BRONZE_INGOT), method_10426(ModItems.BRONZE_INGOT))
                    .method_10431(field_53721);

                // Netherite Titanium Tools
                method_62746(class_7800.field_40638, ModItems.NETHERITE_TITANIUM_SWORD)
                    .method_10439("N").method_10439("N").method_10439("S")
                    .method_10434('N', ModItems.NETHERITE_TITANIUM_INGOT).method_10434('S', class_1802.field_8600)
                    .method_10429(method_32807(ModItems.NETHERITE_TITANIUM_INGOT), method_10426(ModItems.NETHERITE_TITANIUM_INGOT))
                    .method_10431(field_53721);

                method_62746(class_7800.field_40638, ModItems.NETHERITE_TITANIUM_PICKAXE)
                    .method_10439("NNN").method_10439(" S ").method_10439(" S ")
                    .method_10434('N', ModItems.NETHERITE_TITANIUM_INGOT).method_10434('S', class_1802.field_8600)
                    .method_10429(method_32807(ModItems.NETHERITE_TITANIUM_INGOT), method_10426(ModItems.NETHERITE_TITANIUM_INGOT))
                    .method_10431(field_53721);

                method_62746(class_7800.field_40638, ModItems.NETHERITE_TITANIUM_AXE)
                    .method_10439("NN").method_10439("NS").method_10439(" S")
                    .method_10434('N', ModItems.NETHERITE_TITANIUM_INGOT).method_10434('S', class_1802.field_8600)
                    .method_10429(method_32807(ModItems.NETHERITE_TITANIUM_INGOT), method_10426(ModItems.NETHERITE_TITANIUM_INGOT))
                    .method_10431(field_53721);

                method_62746(class_7800.field_40638, ModItems.NETHERITE_TITANIUM_SHOVEL)
                    .method_10439("N").method_10439("S").method_10439("S")
                    .method_10434('N', ModItems.NETHERITE_TITANIUM_INGOT).method_10434('S', class_1802.field_8600)
                    .method_10429(method_32807(ModItems.NETHERITE_TITANIUM_INGOT), method_10426(ModItems.NETHERITE_TITANIUM_INGOT))
                    .method_10431(field_53721);

                method_62746(class_7800.field_40638, ModItems.NETHERITE_TITANIUM_HOE)
                    .method_10439("NN").method_10439(" S").method_10439(" S")
                    .method_10434('N', ModItems.NETHERITE_TITANIUM_INGOT).method_10434('S', class_1802.field_8600)
                    .method_10429(method_32807(ModItems.NETHERITE_TITANIUM_INGOT), method_10426(ModItems.NETHERITE_TITANIUM_INGOT))
                    .method_10431(field_53721);

                // Netherite Titanium Armor
                method_62746(class_7800.field_40639, ModItems.NETHERITE_TITANIUM_HELMET)
                    .method_10439("NNN").method_10439("N N")
                    .method_10434('N', ModItems.NETHERITE_TITANIUM_INGOT)
                    .method_10429(method_32807(ModItems.NETHERITE_TITANIUM_INGOT), method_10426(ModItems.NETHERITE_TITANIUM_INGOT))
                    .method_10431(field_53721);

                method_62746(class_7800.field_40639, ModItems.NETHERITE_TITANIUM_CHESTPLATE)
                    .method_10439("N N").method_10439("NNN").method_10439("NNN")
                    .method_10434('N', ModItems.NETHERITE_TITANIUM_INGOT)
                    .method_10429(method_32807(ModItems.NETHERITE_TITANIUM_INGOT), method_10426(ModItems.NETHERITE_TITANIUM_INGOT))
                    .method_10431(field_53721);

                method_62746(class_7800.field_40639, ModItems.NETHERITE_TITANIUM_LEGGINGS)
                    .method_10439("NNN").method_10439("N N").method_10439("N N")
                    .method_10434('N', ModItems.NETHERITE_TITANIUM_INGOT)
                    .method_10429(method_32807(ModItems.NETHERITE_TITANIUM_INGOT), method_10426(ModItems.NETHERITE_TITANIUM_INGOT))
                    .method_10431(field_53721);

                method_62746(class_7800.field_40639, ModItems.NETHERITE_TITANIUM_BOOTS)
                    .method_10439("N N").method_10439("N N")
                    .method_10434('N', ModItems.NETHERITE_TITANIUM_INGOT)
                    .method_10429(method_32807(ModItems.NETHERITE_TITANIUM_INGOT), method_10426(ModItems.NETHERITE_TITANIUM_INGOT))
                    .method_10431(field_53721);

                // Titanium building blocks
                method_62747(class_7800.field_40634, ModBlocks.TITANIUM_GRATE, 4)
                    .method_10439(" T ")
                    .method_10439("T T")
                    .method_10439(" T ")
                    .method_10434('T', ModItems.TITANIUM_INGOT)
                    .method_10429(method_32807(ModItems.TITANIUM_INGOT), method_10426(ModItems.TITANIUM_INGOT))
                    .method_10431(field_53721);

                method_62747(class_7800.field_40634, ModBlocks.TITANIUM_STAIRS, 4)
                    .method_10439("T  ")
                    .method_10439("TT ")
                    .method_10439("TTT")
                    .method_10434('T', ModBlocks.TITANIUM_BLOCK)
                    .method_10429(method_32807(ModBlocks.TITANIUM_BLOCK), method_10426(ModBlocks.TITANIUM_BLOCK))
                    .method_10431(field_53721);

                method_62747(class_7800.field_40634, ModBlocks.TITANIUM_SLAB, 6)
                    .method_10439("TTT")
                    .method_10434('T', ModBlocks.TITANIUM_BLOCK)
                    .method_10429(method_32807(ModBlocks.TITANIUM_BLOCK), method_10426(ModBlocks.TITANIUM_BLOCK))
                    .method_10431(field_53721);

                method_62747(class_7800.field_40635, ModBlocks.TITANIUM_BARS, 16)
                    .method_10439("TTT")
                    .method_10439("TTT")
                    .method_10434('T', ModItems.TITANIUM_INGOT)
                    .method_10429(method_32807(ModItems.TITANIUM_INGOT), method_10426(ModItems.TITANIUM_INGOT))
                    .method_10431(field_53721);

                method_62747(class_7800.field_40636, ModBlocks.TITANIUM_DOOR, 3)
                    .method_10439("TT")
                    .method_10439("TT")
                    .method_10439("TT")
                    .method_10434('T', ModItems.TITANIUM_INGOT)
                    .method_10429(method_32807(ModItems.TITANIUM_INGOT), method_10426(ModItems.TITANIUM_INGOT))
                    .method_10431(field_53721);

                method_62746(class_7800.field_40636, ModBlocks.TITANIUM_TRAPDOOR)
                    .method_10439("TT")
                    .method_10439("TT")
                    .method_10434('T', ModItems.TITANIUM_INGOT)
                    .method_10429(method_32807(ModItems.TITANIUM_INGOT), method_10426(ModItems.TITANIUM_INGOT))
                    .method_10431(field_53721);

                // Bag
                method_62746(class_7800.field_40638, ModItems.BAG)
                    .method_10439("KCK")
                    .method_10439("VIV")
                    .method_10439("KKK")
                    .method_10434('K', class_1802.field_8745)
                    .method_10434('C', class_1802.field_8106)
                    .method_10434('V', ModItems.FIBER)
                    .method_10434('I', class_1802.field_8620)
                    .method_10429(method_32807(ModItems.FIBER), method_10426(ModItems.FIBER))
                    .method_10431(field_53721);
            }
        };
    }

    @Override
    public String method_10321() {
        return "Caveborn Recipes";
    }
}
