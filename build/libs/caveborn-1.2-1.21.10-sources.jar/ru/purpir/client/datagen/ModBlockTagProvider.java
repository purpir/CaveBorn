package ru.purpir.client.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_3481;
import net.minecraft.class_7225;
import ru.purpir.block.ModBlocks;

import java.util.concurrent.CompletableFuture;

public class ModBlockTagProvider extends FabricTagProvider.BlockTagProvider {
    public ModBlockTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 wrapperLookup) {
        valueLookupBuilder(class_3481.field_33715)
            .method_71554(ModBlocks.BRONZE_ORE)
            .method_71554(ModBlocks.BRONZE_BLOCK)
            .method_71554(ModBlocks.TITANIUM_ORE)
            .method_71554(ModBlocks.DEEPSLATE_TITANIUM_ORE)
            .method_71554(ModBlocks.TITANIUM_BLOCK)
            .method_71554(ModBlocks.NETHERITE_TITANIUM_BLOCK)
            .method_71554(ModBlocks.TITANIUM_GRATE)
            .method_71554(ModBlocks.TITANIUM_STAIRS)
            .method_71554(ModBlocks.TITANIUM_SLAB)
            .method_71554(ModBlocks.TITANIUM_BARS)
            .method_71554(ModBlocks.TITANIUM_DOOR)
            .method_71554(ModBlocks.TITANIUM_TRAPDOOR);

        valueLookupBuilder(class_3481.field_49930)
            .method_71554(ModBlocks.BRONZE_ORE)
            .method_71554(ModBlocks.BRONZE_BLOCK)
            .method_71554(ModBlocks.TITANIUM_ORE)
            .method_71554(ModBlocks.DEEPSLATE_TITANIUM_ORE)
            .method_71554(ModBlocks.TITANIUM_BLOCK)
            .method_71554(ModBlocks.NETHERITE_TITANIUM_BLOCK)
            .method_71554(ModBlocks.TITANIUM_GRATE)
            .method_71554(ModBlocks.TITANIUM_STAIRS)
            .method_71554(ModBlocks.TITANIUM_SLAB)
            .method_71554(ModBlocks.TITANIUM_BARS)
            .method_71554(ModBlocks.TITANIUM_DOOR)
            .method_71554(ModBlocks.TITANIUM_TRAPDOOR);

        valueLookupBuilder(class_3481.field_49928)
            .method_71554(ModBlocks.BRONZE_ORE)
            .method_71554(ModBlocks.BRONZE_BLOCK)
            .method_71554(ModBlocks.TITANIUM_ORE)
            .method_71554(ModBlocks.DEEPSLATE_TITANIUM_ORE)
            .method_71554(ModBlocks.TITANIUM_BLOCK)
            .method_71554(ModBlocks.NETHERITE_TITANIUM_BLOCK)
            .method_71554(ModBlocks.TITANIUM_GRATE)
            .method_71554(ModBlocks.TITANIUM_STAIRS)
            .method_71554(ModBlocks.TITANIUM_SLAB)
            .method_71554(ModBlocks.TITANIUM_BARS)
            .method_71554(ModBlocks.TITANIUM_DOOR)
            .method_71554(ModBlocks.TITANIUM_TRAPDOOR);

        valueLookupBuilder(class_3481.field_49929)
            .method_71554(ModBlocks.BRONZE_ORE)
            .method_71554(ModBlocks.BRONZE_BLOCK)
            .method_71554(ModBlocks.TITANIUM_ORE)
            .method_71554(ModBlocks.DEEPSLATE_TITANIUM_ORE)
            .method_71554(ModBlocks.TITANIUM_BLOCK)
            .method_71554(ModBlocks.NETHERITE_TITANIUM_BLOCK)
            .method_71554(ModBlocks.TITANIUM_GRATE)
            .method_71554(ModBlocks.TITANIUM_STAIRS)
            .method_71554(ModBlocks.TITANIUM_SLAB)
            .method_71554(ModBlocks.TITANIUM_BARS)
            .method_71554(ModBlocks.TITANIUM_DOOR)
            .method_71554(ModBlocks.TITANIUM_TRAPDOOR);

        valueLookupBuilder(class_3481.field_49927)
            .method_71554(ModBlocks.TITANIUM_ORE)
            .method_71554(ModBlocks.DEEPSLATE_TITANIUM_ORE)
            .method_71554(ModBlocks.TITANIUM_BLOCK)
            .method_71554(ModBlocks.NETHERITE_TITANIUM_BLOCK)
            .method_71554(ModBlocks.TITANIUM_GRATE)
            .method_71554(ModBlocks.TITANIUM_STAIRS)
            .method_71554(ModBlocks.TITANIUM_SLAB)
            .method_71554(ModBlocks.TITANIUM_BARS)
            .method_71554(ModBlocks.TITANIUM_DOOR)
            .method_71554(ModBlocks.TITANIUM_TRAPDOOR);

        valueLookupBuilder(class_3481.field_49926)
            .method_71554(ModBlocks.TITANIUM_ORE)
            .method_71554(ModBlocks.DEEPSLATE_TITANIUM_ORE)
            .method_71554(ModBlocks.TITANIUM_BLOCK)
            .method_71554(ModBlocks.NETHERITE_TITANIUM_BLOCK)
            .method_71554(ModBlocks.TITANIUM_GRATE)
            .method_71554(ModBlocks.TITANIUM_STAIRS)
            .method_71554(ModBlocks.TITANIUM_SLAB)
            .method_71554(ModBlocks.TITANIUM_BARS)
            .method_71554(ModBlocks.TITANIUM_DOOR)
            .method_71554(ModBlocks.TITANIUM_TRAPDOOR);

        // Door and trapdoor tags
        valueLookupBuilder(class_3481.field_15495)
            .method_71554(ModBlocks.TITANIUM_DOOR);
        
        valueLookupBuilder(class_3481.field_15487)
            .method_71554(ModBlocks.TITANIUM_TRAPDOOR);

        valueLookupBuilder(class_3481.field_15469)
            .method_71554(ModBlocks.TITANIUM_SLAB);

        valueLookupBuilder(class_3481.field_15459)
            .method_71554(ModBlocks.TITANIUM_STAIRS);
    }
}
