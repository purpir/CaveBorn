package ru.purpir.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.minecraft.class_11515;
import ru.purpir.block.ModBlocks;

public class CavebornClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        // Регистрируем прозрачный рендер для сорняков
        BlockRenderLayerMap.putBlock(ModBlocks.WEED, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.WEED_TOP, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.HOGWEED, class_11515.field_60925);
        
        // Прозрачность для титановых блоков
        BlockRenderLayerMap.putBlock(ModBlocks.TITANIUM_GRATE, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.TITANIUM_BARS, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.TITANIUM_DOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.TITANIUM_TRAPDOOR, class_11515.field_60925);
    }
}
