package ru.purpir.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.minecraft.class_11515;
import net.minecraft.class_3929;
import ru.purpir.block.ModBlocks;
import ru.purpir.client.screen.BagScreen;
import ru.purpir.screen.ModScreenHandlers;

public class CavebornClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        // Регистрируем экран сумки
        class_3929.method_17542(ModScreenHandlers.BAG_SCREEN_HANDLER, BagScreen::new);
        
        // Регистрируем прозрачный рендер для сорняков
        BlockRenderLayerMap.putBlock(ModBlocks.WEED, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.WEED_TOP, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.HOGWEED, class_11515.field_60925);
        
        // Прозрачность для титановых блоков
        BlockRenderLayerMap.putBlock(ModBlocks.TITANIUM_GRATE, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.TITANIUM_BARS, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.TITANIUM_DOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.TITANIUM_TRAPDOOR, class_11515.field_60925);
    }
}
