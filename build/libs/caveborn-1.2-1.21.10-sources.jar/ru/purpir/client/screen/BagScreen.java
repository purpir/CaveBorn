package ru.purpir.client.screen;

import net.minecraft.class_10799;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import ru.purpir.screen.BagScreenHandler;

public class BagScreen extends class_465<BagScreenHandler> {
    private static final class_2960 TEXTURE = class_2960.method_60656("textures/gui/container/generic_54.png");

    public BagScreen(BagScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
        this.field_2779 = 148;
        this.field_25270 = this.field_2779 - 94;
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        int x = (this.field_22789 - this.field_2792) / 2;
        int y = (this.field_22790 - this.field_2779) / 2;
        // Верхняя часть (2 ряда слотов)
        context.method_25290(class_10799.field_56883, TEXTURE, x, y, 0.0f, 0.0f, this.field_2792, 53, 256, 256);
        // Нижняя часть (инвентарь игрока)
        context.method_25290(class_10799.field_56883, TEXTURE, x, y + 53, 0.0f, 126.0f, this.field_2792, 96, 256, 256);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context, mouseX, mouseY, delta);
        super.method_25394(context, mouseX, mouseY, delta);
        this.method_2380(context, mouseX, mouseY);
    }
}
