package ru.purpir.item;

import java.util.Map;
import net.minecraft.class_1741;
import net.minecraft.class_3417;
import net.minecraft.class_8051;

public class ModArmorMaterials {
    // Bronze - same as diamond
    public static final class_1741 BRONZE = new class_1741(
        33,  // durability
        Map.of(
            class_8051.field_41934, 3,
            class_8051.field_41935, 8,
            class_8051.field_41936, 6,
            class_8051.field_41937, 3
        ),
        10,  // enchantability
        class_3417.field_15103,
        2.0f,  // toughness
        0.0f,  // knockback resistance
        ModTags.Items.BRONZE_REPAIR,
        ModEquipmentAssets.BRONZE
    );

    // Netherite Titanium - 2x netherite protection
    public static final class_1741 NETHERITE_TITANIUM = new class_1741(
        74,  // durability (2x netherite's 37)
        Map.of(
            class_8051.field_41934, 6,
            class_8051.field_41935, 16,
            class_8051.field_41936, 12,
            class_8051.field_41937, 6
        ),
        20,  // enchantability
        class_3417.field_21866,
        6.0f,  // toughness
        0.2f,  // knockback resistance
        ModTags.Items.NETHERITE_TITANIUM_REPAIR,
        ModEquipmentAssets.NETHERITE_TITANIUM
    );

    public static void initialize() {
    }
}
