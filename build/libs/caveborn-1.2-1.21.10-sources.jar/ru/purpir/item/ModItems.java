package ru.purpir.item;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8051;
import ru.purpir.Caveborn;
import ru.purpir.block.ModBlocks;

import java.util.function.Function;

public class ModItems {
    // Misc Items
    public static final class_1792 FIBER = registerItem("fiber", class_1792::new, new class_1792.class_1793());
    
    // Bronze Items
    public static final class_1792 BRONZE_INGOT = registerItem("bronze_ingot", class_1792::new, new class_1792.class_1793());
    public static final class_1792 RAW_BRONZE = registerItem("raw_bronze", class_1792::new, new class_1792.class_1793());
    
    public static final class_1792 BRONZE_SWORD = registerItem("bronze_sword", class_1792::new, 
        new class_1792.class_1793().method_66333(ModToolMaterials.BRONZE, 3, -2.4f));
    public static final class_1792 BRONZE_PICKAXE = registerItem("bronze_pickaxe", class_1792::new, 
        new class_1792.class_1793().method_66330(ModToolMaterials.BRONZE, 1, -2.8f));
    public static final class_1792 BRONZE_AXE = registerItem("bronze_axe", class_1792::new, 
        new class_1792.class_1793().method_67190(ModToolMaterials.BRONZE, 5, -3.0f));
    public static final class_1792 BRONZE_SHOVEL = registerItem("bronze_shovel", class_1792::new, 
        new class_1792.class_1793().method_67193(ModToolMaterials.BRONZE, 1.5f, -3.0f));
    public static final class_1792 BRONZE_HOE = registerItem("bronze_hoe", 
        settings -> new class_1794(ModToolMaterials.BRONZE, -3, 0.0f, settings), 
        new class_1792.class_1793());
    
    public static final class_1792 BRONZE_HELMET = registerItem("bronze_helmet", class_1792::new,
        new class_1792.class_1793().method_66332(ModArmorMaterials.BRONZE, class_8051.field_41934));
    public static final class_1792 BRONZE_CHESTPLATE = registerItem("bronze_chestplate", class_1792::new,
        new class_1792.class_1793().method_66332(ModArmorMaterials.BRONZE, class_8051.field_41935));
    public static final class_1792 BRONZE_LEGGINGS = registerItem("bronze_leggings", class_1792::new,
        new class_1792.class_1793().method_66332(ModArmorMaterials.BRONZE, class_8051.field_41936));
    public static final class_1792 BRONZE_BOOTS = registerItem("bronze_boots", class_1792::new,
        new class_1792.class_1793().method_66332(ModArmorMaterials.BRONZE, class_8051.field_41937));

    // Titanium Items
    public static final class_1792 TITANIUM_INGOT = registerItem("titanium_ingot", class_1792::new, new class_1792.class_1793());
    public static final class_1792 RAW_TITANIUM = registerItem("raw_titanium", class_1792::new, new class_1792.class_1793());
    
    // Netherite Titanium Items
    public static final class_1792 NETHERITE_TITANIUM_INGOT = registerItem("netherite_titanium_ingot", 
        class_1792::new, new class_1792.class_1793().method_24359());
    
    public static final class_1792 NETHERITE_TITANIUM_SWORD = registerItem("netherite_titanium_sword", class_1792::new, 
        new class_1792.class_1793().method_24359().method_66333(ModToolMaterials.NETHERITE_TITANIUM, 3, -2.4f));
    public static final class_1792 NETHERITE_TITANIUM_PICKAXE = registerItem("netherite_titanium_pickaxe", class_1792::new, 
        new class_1792.class_1793().method_24359().method_66330(ModToolMaterials.NETHERITE_TITANIUM, 1, -2.8f));
    public static final class_1792 NETHERITE_TITANIUM_AXE = registerItem("netherite_titanium_axe", class_1792::new, 
        new class_1792.class_1793().method_24359().method_67190(ModToolMaterials.NETHERITE_TITANIUM, 5, -3.0f));
    public static final class_1792 NETHERITE_TITANIUM_SHOVEL = registerItem("netherite_titanium_shovel", class_1792::new, 
        new class_1792.class_1793().method_24359().method_67193(ModToolMaterials.NETHERITE_TITANIUM, 1.5f, -3.0f));
    public static final class_1792 NETHERITE_TITANIUM_HOE = registerItem("netherite_titanium_hoe", 
        settings -> new class_1794(ModToolMaterials.NETHERITE_TITANIUM, -4, 0.0f, settings), 
        new class_1792.class_1793().method_24359());
    
    public static final class_1792 NETHERITE_TITANIUM_HELMET = registerItem("netherite_titanium_helmet", class_1792::new,
        new class_1792.class_1793().method_24359().method_66332(ModArmorMaterials.NETHERITE_TITANIUM, class_8051.field_41934));
    public static final class_1792 NETHERITE_TITANIUM_CHESTPLATE = registerItem("netherite_titanium_chestplate", class_1792::new,
        new class_1792.class_1793().method_24359().method_66332(ModArmorMaterials.NETHERITE_TITANIUM, class_8051.field_41935));
    public static final class_1792 NETHERITE_TITANIUM_LEGGINGS = registerItem("netherite_titanium_leggings", class_1792::new,
        new class_1792.class_1793().method_24359().method_66332(ModArmorMaterials.NETHERITE_TITANIUM, class_8051.field_41936));
    public static final class_1792 NETHERITE_TITANIUM_BOOTS = registerItem("netherite_titanium_boots", class_1792::new,
        new class_1792.class_1793().method_24359().method_66332(ModArmorMaterials.NETHERITE_TITANIUM, class_8051.field_41937));

    public static final class_5321<class_1761> CAVEBORN_GROUP = class_5321.method_29179(class_7924.field_44688, 
        class_2960.method_60655(Caveborn.MOD_ID, "caveborn_group"));

    private static class_1792 registerItem(String name, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 settings) {
        class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Caveborn.MOD_ID, name));
        return class_2378.method_39197(class_7923.field_41178, key, factory.apply(settings.method_63686(key)));
    }

    public static void registerModItems() {
        Caveborn.LOGGER.info("Registering Mod Items for " + Caveborn.MOD_ID);
        
        class_2378.method_39197(class_7923.field_44687, CAVEBORN_GROUP,
            FabricItemGroup.builder()
                .method_47320(() -> new class_1799(NETHERITE_TITANIUM_INGOT))
                .method_47321(class_2561.method_43471("itemGroup.caveborn.caveborn_group"))
                .method_47317((context, entries) -> {
                    // Misc
                    entries.method_45421(FIBER);
                    // Bronze
                    entries.method_45421(ModBlocks.BRONZE_ORE);
                    entries.method_45421(ModBlocks.BRONZE_BLOCK);
                    entries.method_45421(BRONZE_INGOT);
                    entries.method_45421(RAW_BRONZE);
                    entries.method_45421(BRONZE_SWORD);
                    entries.method_45421(BRONZE_PICKAXE);
                    entries.method_45421(BRONZE_AXE);
                    entries.method_45421(BRONZE_SHOVEL);
                    entries.method_45421(BRONZE_HOE);
                    entries.method_45421(BRONZE_HELMET);
                    entries.method_45421(BRONZE_CHESTPLATE);
                    entries.method_45421(BRONZE_LEGGINGS);
                    entries.method_45421(BRONZE_BOOTS);
                    // Titanium
                    entries.method_45421(ModBlocks.TITANIUM_ORE);
                    entries.method_45421(ModBlocks.DEEPSLATE_TITANIUM_ORE);
                    entries.method_45421(ModBlocks.TITANIUM_BLOCK);
                    entries.method_45421(ModBlocks.TITANIUM_GRATE);
                    entries.method_45421(ModBlocks.TITANIUM_STAIRS);
                    entries.method_45421(ModBlocks.TITANIUM_SLAB);
                    entries.method_45421(ModBlocks.TITANIUM_BARS);
                    entries.method_45421(ModBlocks.TITANIUM_DOOR);
                    entries.method_45421(ModBlocks.TITANIUM_TRAPDOOR);
                    entries.method_45421(TITANIUM_INGOT);
                    entries.method_45421(RAW_TITANIUM);
                    // Netherite Titanium
                    entries.method_45421(ModBlocks.NETHERITE_TITANIUM_BLOCK);
                    entries.method_45421(NETHERITE_TITANIUM_INGOT);
                    entries.method_45421(NETHERITE_TITANIUM_SWORD);
                    entries.method_45421(NETHERITE_TITANIUM_PICKAXE);
                    entries.method_45421(NETHERITE_TITANIUM_AXE);
                    entries.method_45421(NETHERITE_TITANIUM_SHOVEL);
                    entries.method_45421(NETHERITE_TITANIUM_HOE);
                    entries.method_45421(NETHERITE_TITANIUM_HELMET);
                    entries.method_45421(NETHERITE_TITANIUM_CHESTPLATE);
                    entries.method_45421(NETHERITE_TITANIUM_LEGGINGS);
                    entries.method_45421(NETHERITE_TITANIUM_BOOTS);
                })
                .method_47324());
    }
}
