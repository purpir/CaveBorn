package ru.purpir.item;

import net.minecraft.class_10191;
import net.minecraft.class_10394;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import ru.purpir.Caveborn;

public class ModEquipmentAssets {
    public static final class_5321<class_10394> BRONZE = of("bronze");
    public static final class_5321<class_10394> NETHERITE_TITANIUM = of("netherite_titanium");

    private static class_5321<class_10394> of(String name) {
        return class_5321.method_29179(class_10191.field_55214, class_2960.method_60655(Caveborn.MOD_ID, name));
    }
}
