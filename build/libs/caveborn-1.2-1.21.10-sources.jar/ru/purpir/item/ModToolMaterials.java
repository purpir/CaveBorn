package ru.purpir.item;

import net.minecraft.class_3481;
import net.minecraft.class_9886;

public class ModToolMaterials {
    // Bronze - same as diamond
    public static final class_9886 BRONZE = new class_9886(
        class_3481.field_49926, 1561, 8.0f, 3.0f, 10, ModTags.Items.BRONZE_REPAIR);

    // Netherite Titanium - 2x netherite
    public static final class_9886 NETHERITE_TITANIUM = new class_9886(
        class_3481.field_49925, 4062, 18.0f, 8.0f, 20, ModTags.Items.NETHERITE_TITANIUM_REPAIR);
}
