package ru.purpir.item;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_747;
import ru.purpir.screen.BagScreenHandler;

public class BagItem extends class_1792 {
    public BagItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);
        
        if (!world.method_8608()) {
            user.method_17355(new class_747(
                (syncId, playerInventory, player) -> new BagScreenHandler(syncId, playerInventory, stack),
                class_2561.method_43471("item.caveborn.bag")
            ));
        }
        
        return class_1269.field_5812;
    }
}
