package ru.purpir.mixin;

import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.purpir.block.ModBlocks;

@Mixin(class_2302.class)
public class CropBlockMixin {
    
    @Unique
    private static final int WEED_SPREAD_CHANCE = 300; // 1/300 шанс проверить распространение сорняка
    
    @Inject(method = "randomTick", at = @At("HEAD"))
    private void onCropRandomTick(class_2680 state, class_3218 world, class_2338 pos, class_5819 random, CallbackInfo ci) {
        // Культуры не спавнят сорняки сами, это делает FarmlandBlockMixin
        // Но если рядом есть сорняк - он может распространиться
        if (random.method_43048(WEED_SPREAD_CHANCE) == 0) {
            checkForNearbyWeedsAndSpread(world, pos, random);
        }
    }
    
    @Unique
    private void checkForNearbyWeedsAndSpread(class_3218 world, class_2338 cropPos, class_5819 random) {
        // Проверяем есть ли сорняки рядом
        for (class_2350 dir : class_2350.class_2353.field_11062) {
            class_2338 neighborPos = cropPos.method_10093(dir);
            class_2680 neighborState = world.method_8320(neighborPos);
            
            // Если рядом сорняк - он может заразить эту культуру
            if (neighborState.method_27852(ModBlocks.WEED)) {
                if (random.method_43048(5) == 0) { // 1/5 шанс
                    world.method_8501(cropPos, ModBlocks.WEED.method_9564());
                }
                break;
            }
        }
    }
}
