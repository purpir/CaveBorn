package ru.purpir.mixin;

import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2344;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.purpir.block.ModBlocks;

@Mixin(class_2344.class)
public class FarmlandBlockMixin {
    
    @Unique
    private static final int WEED_SPAWN_CHANCE_EMPTY = 500; // 1/500 шанс если грядка пустая
    @Unique
    private static final int WEED_SPAWN_CHANCE_CROP = 400; // 1/400 шанс если на грядке культура
    
    @Inject(method = "randomTick", at = @At("HEAD"))
    private void onRandomTick(class_2680 state, class_3218 world, class_2338 pos, class_5819 random, CallbackInfo ci) {
        class_2338 above = pos.method_10084();
        class_2680 aboveState = world.method_8320(above);
        
        // Если над грядкой пусто - шанс заспавнить сорняк
        if (aboveState.method_26215()) {
            if (random.method_43048(WEED_SPAWN_CHANCE_EMPTY) == 0) {
                world.method_8501(above, ModBlocks.WEED.method_9564());
            }
        }
        // Если над грядкой культура - шанс заменить её сорняком
        else if (aboveState.method_26204() instanceof class_2302 || aboveState.method_26164(class_3481.field_20341)) {
            if (random.method_43048(WEED_SPAWN_CHANCE_CROP) == 0) {
                // Сорняк заменяет культуру!
                world.method_8501(above, ModBlocks.WEED.method_9564());
            }
        }
    }
}
