package ru.purpir.mixin.client;

import net.minecraft.class_12074;
import net.minecraft.class_2338;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Миксин для кастомного рендера outline мультиблоков.
 * Позволяет рисовать единый хитбокс для блоков, занимающих несколько позиций.
 */
@Mixin(class_761.class)
public class WorldRendererMixin {

    @Unique
    private static class_2338 lastMultiblockOrigin = null;

    /**
     * Перехватывает рисование outline блока.
     * Для мультиблоков можно переопределить форму и предотвратить дублирование.
     */
    @Inject(method = "drawBlockOutline", at = @At("HEAD"), cancellable = true)
    private void onDrawBlockOutline(class_4587 matrices, class_4588 vertexConsumer,
                                     double x, double y, double z,
                                     class_12074 state, int color, CallbackInfo ci) {
        // TODO: Добавить проверку на мультиблоки здесь
        // Пример использования:
        // BlockPos pos = state.pos();
        // BlockState blockState = MinecraftClient.getInstance().world.getBlockState(pos);
        // if (blockState.getBlock() instanceof IMultiblock multiblock) {
        //     BlockPos originPos = multiblock.getOriginPos(pos, blockState);
        //     if (originPos.equals(lastMultiblockOrigin)) {
        //         ci.cancel();
        //         return;
        //     }
        //     lastMultiblockOrigin = originPos;
        //     VoxelShape shape = multiblock.getFullOutlineShape(blockState);
        //     VertexRendering.drawOutline(matrices, vertexConsumer, shape,
        //         (double)pos.getX() - x, (double)pos.getY() - y, (double)pos.getZ() - z, color);
        //     ci.cancel();
        // }
    }

    /**
     * Сбрасывает флаг мультиблока в начале каждого кадра.
     */
    @Inject(method = "render", at = @At("HEAD"))
    private void onRenderStart(CallbackInfo ci) {
        lastMultiblockOrigin = null;
    }
}
