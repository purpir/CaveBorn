package ru.purpir.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2261;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_3726;
import net.minecraft.class_4538;

/**
 * Борщевик - высокое растение от 2 до 8 блоков
 * Спавнится сразу высоким, НЕ растёт
 * Нижние и средние блоки - стебель
 * Верхний блок - зонтик
 */
public class HogweedBlock extends class_2261 {
    public static final MapCodec<HogweedBlock> CODEC = method_54094(HogweedBlock::new);
    
    // true = это верхушка (зонтик), false = стебель
    public static final class_2746 TOP = class_2746.method_11825("top");
    
    private static final class_265 SHAPE = class_2248.method_9541(4, 0, 4, 12, 16, 12);
    
    public HogweedBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664().method_11657(TOP, true));
    }
    
    @Override
    protected MapCodec<? extends class_2261> method_53969() {
        return field_46280;
    }
    
    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(TOP);
    }
    
    @Override
    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }
    
    @Override
    protected boolean method_9695(class_2680 floor, class_1922 world, class_2338 pos) {
        return floor.method_27852(class_2246.field_10219) || floor.method_27852(class_2246.field_10566) || 
               floor.method_27852(class_2246.field_10520) || floor.method_27852(class_2246.field_10253) ||
               floor.method_27852(ModBlocks.HOGWEED); // Может стоять на себе (стебель)
    }
    
    @Override
    public boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        class_2338 below = pos.method_10074();
        class_2680 belowState = world.method_8320(below);
        return method_9695(belowState, world, below);
    }
    
    @Override
    public class_2680 method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        // Когда ломаем любую часть - всё что выше падает
        if (!world.method_8608()) {
            class_2338 above = pos.method_10084();
            class_2680 aboveState = world.method_8320(above);
            if (aboveState.method_27852(ModBlocks.HOGWEED)) {
                world.method_22352(above, true);
            }
        }
        return super.method_9576(world, pos, state, player);
    }
}
