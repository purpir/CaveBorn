package ru.purpir.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_4538;

public class WeedTopBlock extends class_2248 {
    public static final MapCodec<WeedTopBlock> CODEC = method_54094(WeedTopBlock::new);
    private static final class_265 SHAPE = class_2248.method_9541(2, 0, 2, 14, 14, 14);
    
    public WeedTopBlock(class_2251 settings) {
        super(settings);
    }
    
    @Override
    protected MapCodec<? extends class_2248> method_53969() {
        return field_46280;
    }
    
    @Override
    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }
    
    @Override
    public boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        class_2338 below = pos.method_10074();
        class_2680 belowState = world.method_8320(below);
        return belowState.method_27852(ModBlocks.WEED) && belowState.method_11654(WeedBlock.AGE) == 1;
    }
    
    @Override
    public class_2680 method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        // Когда ломаем верх, нижняя часть становится маленькой
        class_2338 below = pos.method_10074();
        class_2680 belowState = world.method_8320(below);
        if (belowState.method_27852(ModBlocks.WEED)) {
            world.method_8501(below, belowState.method_11657(WeedBlock.AGE, 0));
        }
        return super.method_9576(world, pos, state, player);
    }
}
