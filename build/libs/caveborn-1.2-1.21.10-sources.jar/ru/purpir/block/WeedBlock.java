package ru.purpir.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2261;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import java.util.ArrayList;
import java.util.List;

public class WeedBlock extends class_2261 {
    public static final MapCodec<WeedBlock> CODEC = method_54094(WeedBlock::new);
    public static final class_2758 AGE = class_2758.method_11867("age", 0, 1); // 0 = маленький, 1 = большой (2 блока)
    
    private static final class_265 SMALL_SHAPE = class_2248.method_9541(2, 0, 2, 14, 12, 14);
    private static final class_265 TALL_SHAPE = class_2248.method_9541(2, 0, 2, 14, 16, 14);
    
    // Шанс появления сорняка на грядке (1/15 за проверку)
    private static final int SPAWN_CHANCE = 15;
    // Шанс роста сорняка (1/20 за random tick)
    private static final int GROW_CHANCE = 20;
    // Порог для распространения на обычную землю
    private static final int SPREAD_TO_DIRT_THRESHOLD = 20;
    // Шанс распространения на обычную землю (1/300 за тик)
    private static final int SPREAD_TO_DIRT_CHANCE = 300;
    
    public WeedBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664().method_11657(AGE, 0));
    }
    
    @Override
    protected MapCodec<? extends class_2261> method_53969() {
        return field_46280;
    }
    
    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(AGE);
    }
    
    @Override
    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return state.method_11654(AGE) == 0 ? SMALL_SHAPE : TALL_SHAPE;
    }
    
    @Override
    protected boolean method_9695(class_2680 floor, class_1922 world, class_2338 pos) {
        return floor.method_27852(class_2246.field_10362) || floor.method_27852(class_2246.field_10566) || floor.method_27852(class_2246.field_10219);
    }
    
    @Override
    public boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        class_2338 below = pos.method_10074();
        return method_9695(world.method_8320(below), world, below);
    }

    @Override
    protected boolean method_9542(class_2680 state) {
        return true;
    }
    
    @Override
    protected void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        int age = state.method_11654(AGE);
        
        if (age == 0) {
            // Маленький сорняк - шанс вырасти
            if (random.method_43048(GROW_CHANCE) == 0) {
                // Проверяем есть ли место сверху
                class_2338 above = pos.method_10084();
                if (world.method_22347(above)) {
                    world.method_8501(pos, state.method_11657(AGE, 1));
                    world.method_8501(above, ModBlocks.WEED_TOP.method_9564());
                }
            }
        } else {
            // Большой сорняк (2 блока) - заражает соседние грядки
            spreadToNeighbors(world, pos, random);
            
            // Проверяем количество сорняков рядом для распространения на обычную землю
            int nearbyWeeds = countNearbyWeeds(world, pos);
            if (nearbyWeeds >= SPREAD_TO_DIRT_THRESHOLD) {
                if (random.method_43048(SPREAD_TO_DIRT_CHANCE) == 0) {
                    spreadToDirt(world, pos, random);
                }
            }
        }
    }
    
    private void spreadToNeighbors(class_3218 world, class_2338 pos, class_5819 random) {
        // Выбираем 2 случайные стороны из 4
        List<class_2350> horizontalDirs = new ArrayList<>();
        horizontalDirs.add(class_2350.field_11043);
        horizontalDirs.add(class_2350.field_11035);
        horizontalDirs.add(class_2350.field_11034);
        horizontalDirs.add(class_2350.field_11039);
        shuffleDirections(horizontalDirs, random);
        
        int spreadCount = 0;
        for (class_2350 dir : horizontalDirs) {
            if (spreadCount >= 2) break;
            
            class_2338 targetPos = pos.method_10093(dir);
            class_2338 belowTarget = targetPos.method_10074();
            class_2680 belowState = world.method_8320(belowTarget);
            
            // Заражаем только грядки (farmland)
            if (belowState.method_27852(class_2246.field_10362) && world.method_22347(targetPos)) {
                if (random.method_43048(50) == 0) { // Дополнительный шанс
                    world.method_8501(targetPos, ModBlocks.WEED.method_9564());
                    spreadCount++;
                }
            }
        }
    }
    
    private static void shuffleDirections(List<class_2350> list, class_5819 random) {
        for (int i = list.size() - 1; i > 0; i--) {
            int j = random.method_43048(i + 1);
            class_2350 temp = list.get(i);
            list.set(i, list.get(j));
            list.set(j, temp);
        }
    }
    
    private void spreadToDirt(class_3218 world, class_2338 pos, class_5819 random) {
        List<class_2350> horizontalDirs = new ArrayList<>();
        horizontalDirs.add(class_2350.field_11043);
        horizontalDirs.add(class_2350.field_11035);
        horizontalDirs.add(class_2350.field_11034);
        horizontalDirs.add(class_2350.field_11039);
        shuffleDirections(horizontalDirs, random);
        
        for (class_2350 dir : horizontalDirs) {
            class_2338 targetPos = pos.method_10093(dir);
            class_2338 belowTarget = targetPos.method_10074();
            class_2680 belowState = world.method_8320(belowTarget);
            
            // Распространяемся на обычную землю или траву
            if ((belowState.method_27852(class_2246.field_10566) || belowState.method_27852(class_2246.field_10219)) 
                    && world.method_22347(targetPos)) {
                world.method_8501(targetPos, ModBlocks.WEED.method_9564());
                break;
            }
        }
    }
    
    private int countNearbyWeeds(class_3218 world, class_2338 center) {
        int count = 0;
        for (int x = -3; x <= 3; x++) {
            for (int z = -3; z <= 3; z++) {
                for (int y = -1; y <= 2; y++) {
                    class_2338 checkPos = center.method_10069(x, y, z);
                    class_2680 state = world.method_8320(checkPos);
                    if (state.method_27852(ModBlocks.WEED) || state.method_27852(ModBlocks.WEED_TOP)) {
                        count++;
                    }
                }
            }
        }
        return count;
    }
    
    @Override
    public class_2680 method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        // Если сорняк большой, убираем верхнюю часть
        if (state.method_11654(AGE) == 1) {
            class_2338 above = pos.method_10084();
            if (world.method_8320(above).method_27852(ModBlocks.WEED_TOP)) {
                world.method_22352(above, false);
            }
        }
        return super.method_9576(world, pos, state, player);
    }
    
    // Статический метод для спавна сорняков на грядках
    public static void trySpawnOnFarmland(class_3218 world, class_2338 farmlandPos, class_5819 random) {
        if (random.method_43048(SPAWN_CHANCE) == 0) {
            class_2338 above = farmlandPos.method_10084();
            class_2680 aboveState = world.method_8320(above);
            
            // Спавним если там пусто
            if (world.method_22347(above)) {
                world.method_8501(above, ModBlocks.WEED.method_9564());
                return;
            }
            
            // Если там культура - ищем свободное место рядом на грядке
            if (aboveState.method_26164(class_3481.field_20341)) {
                for (class_2350 dir : class_2350.class_2353.field_11062) {
                    class_2338 sidePos = above.method_10093(dir);
                    class_2338 belowSide = sidePos.method_10074();
                    if (world.method_22347(sidePos) && world.method_8320(belowSide).method_27852(class_2246.field_10362)) {
                        world.method_8501(sidePos, ModBlocks.WEED.method_9564());
                        return;
                    }
                }
            }
        }
    }
}
