package ru.purpir.block;

import net.minecraft.block.*;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2323;
import net.minecraft.class_2378;
import net.minecraft.class_2389;
import net.minecraft.class_2431;
import net.minecraft.class_2482;
import net.minecraft.class_2498;
import net.minecraft.class_2510;
import net.minecraft.class_2533;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_6019;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8177;
import net.minecraft.class_9009;
import ru.purpir.Caveborn;

import java.util.function.Function;

public class ModBlocks {
    // Bronze Ore - spawns in End
    public static final class_2248 BRONZE_ORE = registerBlock("bronze_ore",
        settings -> new class_2431(class_6019.method_35017(3, 7), settings),
        class_4970.class_2251.method_9637()
            .method_9629(3.0f, 3.0f)
            .method_29292()
            .method_9626(class_2498.field_11544));
    
    public static final class_2248 BRONZE_BLOCK = registerBlock("bronze_block",
        class_2248::new,
        class_4970.class_2251.method_9637()
            .method_9629(5.0f, 6.0f)
            .method_29292()
            .method_9626(class_2498.field_11533));

    // Titanium Ore - spawns in Overworld, very rare, needs netherite pickaxe
    public static final class_2248 TITANIUM_ORE = registerBlock("titanium_ore",
        settings -> new class_2431(class_6019.method_35017(5, 10), settings),
        class_4970.class_2251.method_9637()
            .method_9629(50.0f, 1200.0f)
            .method_29292()
            .method_9626(class_2498.field_11544));
    
    public static final class_2248 DEEPSLATE_TITANIUM_ORE = registerBlock("deepslate_titanium_ore",
        settings -> new class_2431(class_6019.method_35017(5, 10), settings),
        class_4970.class_2251.method_9637()
            .method_9629(55.0f, 1200.0f)
            .method_29292()
            .method_9626(class_2498.field_29033));
    
    public static final class_2248 TITANIUM_BLOCK = registerBlock("titanium_block",
        class_2248::new,
        class_4970.class_2251.method_9637()
            .method_9629(50.0f, 1200.0f)
            .method_29292()
            .method_9626(class_2498.field_11533));

    // Netherite Titanium Block
    public static final class_2248 NETHERITE_TITANIUM_BLOCK = registerBlock("netherite_titanium_block",
        class_2248::new,
        class_4970.class_2251.method_9637()
            .method_9629(100.0f, 2400.0f)
            .method_29292()
            .method_9626(class_2498.field_22150));

    // Vacuumite - rare End material, easy to mine (stone pickaxe)
    public static final class_2248 VACUUMITE_ORE = registerBlock("vacuumite_ore",
        settings -> new class_2431(class_6019.method_35017(4, 9), settings),
        class_4970.class_2251.method_9637()
            .method_9629(1.5f, 1.5f)
            .method_29292()
            .method_9626(class_2498.field_11544));
    
    public static final class_2248 VACUUMITE_BLOCK = registerBlock("vacuumite_block",
        class_2248::new,
        class_4970.class_2251.method_9637()
            .method_9629(2.0f, 2.0f)
            .method_29292()
            .method_9626(class_2498.field_11533));

    // Weed blocks
    public static final class_2248 WEED = registerBlockNoItem("weed",
        WeedBlock::new,
        class_4970.class_2251.method_9637()
            .method_9634()
            .method_9618()
            .method_9626(class_2498.field_11535)
            .method_9640());
    
    public static final class_2248 WEED_TOP = registerBlockNoItem("weed_top",
        WeedTopBlock::new,
        class_4970.class_2251.method_9637()
            .method_9634()
            .method_9618()
            .method_9626(class_2498.field_11535));

    // Hogweed (Борщевик) - высокое растение 2-8 блоков, НЕ растёт
    public static final class_2248 HOGWEED = registerBlockNoItem("hogweed",
        HogweedBlock::new,
        class_4970.class_2251.method_9637()
            .method_9634()
            .method_9618()
            .method_9626(class_2498.field_11535));

    // Titanium building blocks
    public static final class_2248 TITANIUM_GRATE = registerBlock("titanium_grate",
        class_9009::new,
        class_4970.class_2251.method_9637()
            .method_9629(50.0f, 1200.0f)
            .method_29292()
            .method_9626(class_2498.field_47086)
            .method_22488()
            .method_26235(class_2246::method_26114)
            .method_26236(class_2246::method_26122)
            .method_26243(class_2246::method_26122)
            .method_26245(class_2246::method_26122));

    public static final class_2248 TITANIUM_STAIRS = registerBlock("titanium_stairs",
        settings -> new class_2510(TITANIUM_BLOCK.method_9564(), settings),
        class_4970.class_2251.method_9637()
            .method_9629(50.0f, 1200.0f)
            .method_29292()
            .method_9626(class_2498.field_11533));

    public static final class_2248 TITANIUM_SLAB = registerBlock("titanium_slab",
        class_2482::new,
        class_4970.class_2251.method_9637()
            .method_9629(50.0f, 1200.0f)
            .method_29292()
            .method_9626(class_2498.field_11533));

    public static final class_2248 TITANIUM_BARS = registerBlock("titanium_bars",
        class_2389::new,
        class_4970.class_2251.method_9637()
            .method_9629(50.0f, 1200.0f)
            .method_29292()
            .method_9626(class_2498.field_11533)
            .method_22488());

    public static final class_8177 TITANIUM_BLOCK_SET_TYPE = new class_8177(
        "titanium",
        false, // canOpenByHand - false для редстоун-only (как железная дверь)
        false, // canOpenByWindCharge
        false, // canButtonBeActivatedByArrows
        class_8177.class_2441.field_11362, // pressurePlateSensitivity
        class_2498.field_11533,
        class_3417.field_14819,
        class_3417.field_14567,
        class_3417.field_15131,
        class_3417.field_15082,
        class_3417.field_15100,
        class_3417.field_14988,
        class_3417.field_14954,
        class_3417.field_14791
    );

    public static final class_2248 TITANIUM_DOOR = registerBlock("titanium_door",
        settings -> new class_2323(TITANIUM_BLOCK_SET_TYPE, settings),
        class_4970.class_2251.method_9637()
            .method_31710(class_3620.field_15993)
            .method_9629(50.0f, 1200.0f)
            .method_29292()
            .method_22488()
            .method_50012(class_3619.field_15971));

    public static final class_2248 TITANIUM_TRAPDOOR = registerBlock("titanium_trapdoor",
        settings -> new class_2533(TITANIUM_BLOCK_SET_TYPE, settings),
        class_4970.class_2251.method_9637()
            .method_31710(class_3620.field_15993)
            .method_9629(50.0f, 1200.0f)
            .method_29292()
            .method_22488()
            .method_26235(class_2246::method_26114));

    private static class_2248 registerBlock(String name, Function<class_4970.class_2251, class_2248> factory, 
                                        class_4970.class_2251 settings) {
        class_5321<class_2248> blockKey = class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(Caveborn.MOD_ID, name));
        class_2248 block = class_2378.method_39197(class_7923.field_41175, blockKey, factory.apply(settings.method_63500(blockKey)));
        registerBlockItem(name, block);
        return block;
    }

    private static class_2248 registerBlockNoItem(String name, Function<class_4970.class_2251, class_2248> factory, 
                                              class_4970.class_2251 settings) {
        class_5321<class_2248> blockKey = class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(Caveborn.MOD_ID, name));
        return class_2378.method_39197(class_7923.field_41175, blockKey, factory.apply(settings.method_63500(blockKey)));
    }

    private static void registerBlockItem(String name, class_2248 block) {
        class_5321<class_1792> itemKey = class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Caveborn.MOD_ID, name));
        class_2378.method_39197(class_7923.field_41178, itemKey, new class_1747(block, new class_1792.class_1793().method_63686(itemKey).method_63685()));
    }

    public static void registerModBlocks() {
        Caveborn.LOGGER.info("Registering Mod Blocks for " + Caveborn.MOD_ID);
    }
}
