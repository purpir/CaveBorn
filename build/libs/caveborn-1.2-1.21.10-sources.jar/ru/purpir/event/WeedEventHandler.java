package ru.purpir.event;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_5819;
import ru.purpir.block.WeedBlock;

public class WeedEventHandler {
    private static int tickCounter = 0;
    private static final int CHECK_INTERVAL = 20; // Проверяем каждые 20 тиков (1 секунда)
    
    public static void register() {
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            tickCounter++;
            if (tickCounter >= CHECK_INTERVAL) {
                tickCounter = 0;
                checkFarmlandForWeeds(world);
            }
        });
    }
    
    private static void checkFarmlandForWeeds(class_3218 world) {
        class_5819 random = world.method_8409();
        
        // Проверяем грядки вокруг игроков
        world.method_18456().forEach(player -> {
            class_2338 playerPos = player.method_24515();
            int radius = 16; // Радиус проверки вокруг игрока
            
            // Проверяем больше позиций
            for (int i = 0; i < 20; i++) {
                int x = playerPos.method_10263() + random.method_43048(radius * 2) - radius;
                int z = playerPos.method_10260() + random.method_43048(radius * 2) - radius;
                
                // Ищем грядку по высоте
                for (int y = playerPos.method_10264() - 5; y <= playerPos.method_10264() + 5; y++) {
                    class_2338 checkPos = new class_2338(x, y, z);
                    class_2680 state = world.method_8320(checkPos);
                    
                    if (state.method_27852(class_2246.field_10362)) {
                        WeedBlock.trySpawnOnFarmland(world, checkPos, random);
                        break;
                    }
                }
            }
        });
    }
}
