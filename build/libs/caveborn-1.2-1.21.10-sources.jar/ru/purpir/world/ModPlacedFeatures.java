package ru.purpir.world;

import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_5321;
import net.minecraft.class_5450;
import net.minecraft.class_5843;
import net.minecraft.class_6792;
import net.minecraft.class_6793;
import net.minecraft.class_6795;
import net.minecraft.class_6796;
import net.minecraft.class_6797;
import net.minecraft.class_6799;
import net.minecraft.class_6817;
import net.minecraft.class_6880;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.world.gen.placementmodifier.*;
import ru.purpir.Caveborn;

import java.util.List;

public class ModPlacedFeatures {
    public static final class_5321<class_6796> BRONZE_ORE_PLACED_KEY = registerKey("bronze_ore");
    public static final class_5321<class_6796> TITANIUM_ORE_PLACED_KEY = registerKey("titanium_ore");
    public static final class_5321<class_6796> DEEPSLATE_TITANIUM_ORE_PLACED_KEY = registerKey("deepslate_titanium_ore");
    public static final class_5321<class_6796> WEED_PATCH_PLACED_KEY = registerKey("weed_patch");
    public static final class_5321<class_6796> HOGWEED_PATCH_PLACED_KEY = registerKey("hogweed_patch");

    public static void bootstrap(class_7891<class_6796> context) {
        var configuredFeatures = context.method_46799(class_7924.field_41239);

        // Bronze ore in End - common (20 veins per chunk)
        register(context, BRONZE_ORE_PLACED_KEY, 
            configuredFeatures.method_46747(ModConfiguredFeatures.BRONZE_ORE_KEY),
            modifiersWithCount(20, class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(80))));

        // Titanium ore - very rare (1 vein per chunk, only deep underground)
        register(context, TITANIUM_ORE_PLACED_KEY, 
            configuredFeatures.method_46747(ModConfiguredFeatures.TITANIUM_ORE_KEY),
            modifiersWithCount(1, class_6795.method_39634(class_5843.method_33841(-64), class_5843.method_33841(0))));

        // Deepslate Titanium ore - very rare (1 vein per chunk)
        register(context, DEEPSLATE_TITANIUM_ORE_PLACED_KEY, 
            configuredFeatures.method_46747(ModConfiguredFeatures.DEEPSLATE_TITANIUM_ORE_KEY),
            modifiersWithCount(1, class_6795.method_39634(class_5843.method_33841(-64), class_5843.method_33841(-32))));

        // Weed patch - rare in plains (1 per 32 chunks roughly)
        register(context, WEED_PATCH_PLACED_KEY,
            configuredFeatures.method_46747(ModConfiguredFeatures.WEED_PATCH_KEY),
            List.of(
                class_6799.method_39659(32), // 1 в 32 чанках - редко
                class_5450.method_39639(),
                class_6817.field_36078,
                class_6792.method_39614()
            ));

        // Hogweed patch - moderate in taiga/jungle (1 per 8 chunks)
        register(context, HOGWEED_PATCH_PLACED_KEY,
            configuredFeatures.method_46747(ModConfiguredFeatures.HOGWEED_PATCH_KEY),
            List.of(
                class_6799.method_39659(8), // 1 в 8 чанках - умеренно
                class_5450.method_39639(),
                class_6817.field_36078,
                class_6792.method_39614()
            ));
    }

    public static class_5321<class_6796> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41245, class_2960.method_60655(Caveborn.MOD_ID, name));
    }

    private static void register(class_7891<class_6796> context, class_5321<class_6796> key,
                                 class_6880<class_2975<?, ?>> config, List<class_6797> modifiers) {
        context.method_46838(key, new class_6796(config, List.copyOf(modifiers)));
    }

    private static List<class_6797> modifiersWithCount(int count, class_6797 heightModifier) {
        return List.of(class_6793.method_39623(count), class_5450.method_39639(), heightModifier, class_6792.method_39614());
    }
}
