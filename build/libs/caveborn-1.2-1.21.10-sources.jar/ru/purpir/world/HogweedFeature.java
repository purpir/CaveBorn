package ru.purpir.world;

import com.mojang.serialization.Codec;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3031;
import net.minecraft.class_3111;
import net.minecraft.class_5281;
import net.minecraft.class_5819;
import net.minecraft.class_5821;
import ru.purpir.block.HogweedBlock;
import ru.purpir.block.ModBlocks;

/**
 * Генерирует кучки борщевика высотой 2-8 блоков
 */
public class HogweedFeature extends class_3031<class_3111> {
    
    public HogweedFeature(Codec<class_3111> configCodec) {
        super(configCodec);
    }
    
    @Override
    public boolean method_13151(class_5821<class_3111> context) {
        class_5281 world = context.method_33652();
        class_2338 origin = context.method_33655();
        class_5819 random = context.method_33654();
        
        int placed = 0;
        
        // Генерируем кучку борщевика (15-30 растений)
        int count = 15 + random.method_43048(16);
        
        for (int i = 0; i < count; i++) {
            // Случайная позиция в радиусе 6 блоков
            int x = origin.method_10263() + random.method_43048(13) - 6;
            int z = origin.method_10260() + random.method_43048(13) - 6;
            
            // Ищем поверхность
            class_2338.class_2339 pos = new class_2338.class_2339(x, origin.method_10264() + 10, z);
            for (int y = 0; y < 20; y++) {
                pos.method_33098(origin.method_10264() + 10 - y);
                class_2680 ground = world.method_8320(pos);
                class_2680 above = world.method_8320(pos.method_10084());
                
                if (isValidGround(ground) && above.method_26215()) {
                    // Нашли место - генерируем борщевик
                    int height = 2 + random.method_43048(7); // 2-8 блоков
                    if (placeHogweed(world, pos.method_10084(), height)) {
                        placed++;
                    }
                    break;
                }
            }
        }
        
        return placed > 0;
    }
    
    private boolean isValidGround(class_2680 state) {
        return state.method_27852(class_2246.field_10219) || state.method_27852(class_2246.field_10566) || 
               state.method_27852(class_2246.field_10520) || state.method_27852(class_2246.field_10253);
    }
    
    private boolean placeHogweed(class_5281 world, class_2338 basePos, int height) {
        // Проверяем что есть место для всей высоты
        for (int i = 0; i < height; i++) {
            if (!world.method_8320(basePos.method_10086(i)).method_26215()) {
                height = i; // Уменьшаем высоту
                break;
            }
        }
        
        if (height < 2) return false; // Минимум 2 блока
        
        // Ставим стебли (все кроме верхнего)
        for (int i = 0; i < height - 1; i++) {
            world.method_8652(basePos.method_10086(i), 
                ModBlocks.HOGWEED.method_9564().method_11657(HogweedBlock.TOP, false), 2);
        }
        
        // Ставим верхушку
        world.method_8652(basePos.method_10086(height - 1), 
            ModBlocks.HOGWEED.method_9564().method_11657(HogweedBlock.TOP, true), 2);
        
        return true;
    }
}
