package ru.purpir.world;

import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.class_1972;
import net.minecraft.class_2893;

public class ModOreGeneration {
    public static void generateOres() {
        // Bronze ore in End - common
        BiomeModifications.addFeature(
            BiomeSelectors.foundInTheEnd(),
            class_2893.class_2895.field_13176,
            ModPlacedFeatures.BRONZE_ORE_PLACED_KEY
        );

        // Titanium ore in Overworld - very rare
        BiomeModifications.addFeature(
            BiomeSelectors.foundInOverworld(),
            class_2893.class_2895.field_13176,
            ModPlacedFeatures.TITANIUM_ORE_PLACED_KEY
        );

        // Deepslate Titanium ore in Overworld - very rare
        BiomeModifications.addFeature(
            BiomeSelectors.foundInOverworld(),
            class_2893.class_2895.field_13176,
            ModPlacedFeatures.DEEPSLATE_TITANIUM_ORE_PLACED_KEY
        );

        // Weed patches - only in plains biome
        BiomeModifications.addFeature(
            BiomeSelectors.includeByKey(class_1972.field_9451, class_1972.field_9455),
            class_2893.class_2895.field_13178,
            ModPlacedFeatures.WEED_PATCH_PLACED_KEY
        );

        // Hogweed (Борщевик) - in taiga and jungle biomes
        BiomeModifications.addFeature(
            BiomeSelectors.includeByKey(
                class_1972.field_9420, class_1972.field_35119, class_1972.field_35113,
                class_1972.field_9454,
                class_1972.field_9417, class_1972.field_35118, class_1972.field_9440
            ),
            class_2893.class_2895.field_13178,
            ModPlacedFeatures.HOGWEED_PATCH_PLACED_KEY
        );
    }
}
