package ru.purpir.world;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3031;
import net.minecraft.class_3111;
import net.minecraft.class_7923;
import ru.purpir.Caveborn;

public class ModFeatures {
    public static final class_3031<class_3111> HOGWEED = new HogweedFeature(class_3111.field_24893);
    
    public static void register() {
        class_2378.method_10230(class_7923.field_41144, class_2960.method_60655(Caveborn.MOD_ID, "hogweed"), HOGWEED);
    }
}
