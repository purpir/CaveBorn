package ru.purpir.world;

import net.minecraft.class_2246;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_3111;
import net.minecraft.class_3124;
import net.minecraft.class_3175;
import net.minecraft.class_3481;
import net.minecraft.class_3798;
import net.minecraft.class_3819;
import net.minecraft.class_3825;
import net.minecraft.class_4638;
import net.minecraft.class_4651;
import net.minecraft.class_5321;
import net.minecraft.class_6817;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.world.gen.feature.*;
import ru.purpir.Caveborn;
import ru.purpir.block.ModBlocks;

import java.util.List;

public class ModConfiguredFeatures {
    public static final class_5321<class_2975<?, ?>> BRONZE_ORE_KEY = registerKey("bronze_ore");
    public static final class_5321<class_2975<?, ?>> TITANIUM_ORE_KEY = registerKey("titanium_ore");
    public static final class_5321<class_2975<?, ?>> DEEPSLATE_TITANIUM_ORE_KEY = registerKey("deepslate_titanium_ore");
    public static final class_5321<class_2975<?, ?>> WEED_PATCH_KEY = registerKey("weed_patch");
    public static final class_5321<class_2975<?, ?>> HOGWEED_PATCH_KEY = registerKey("hogweed_patch");

    public static void bootstrap(class_7891<class_2975<?, ?>> context) {
        class_3825 endStoneReplaceable = new class_3819(class_2246.field_10471);
        class_3825 stoneReplaceable = new class_3798(class_3481.field_28992);
        class_3825 deepslateReplaceable = new class_3798(class_3481.field_28993);

        // Bronze ore in End - common, vein size 8
        register(context, BRONZE_ORE_KEY, class_3031.field_13517, new class_3124(
            List.of(class_3124.method_33994(endStoneReplaceable, ModBlocks.BRONZE_ORE.method_9564())),
            8));

        // Titanium ore in stone - very rare, vein size 3
        register(context, TITANIUM_ORE_KEY, class_3031.field_13517, new class_3124(
            List.of(class_3124.method_33994(stoneReplaceable, ModBlocks.TITANIUM_ORE.method_9564())),
            3));

        // Titanium ore in deepslate - very rare, vein size 3
        register(context, DEEPSLATE_TITANIUM_ORE_KEY, class_3031.field_13517, new class_3124(
            List.of(class_3124.method_33994(deepslateReplaceable, ModBlocks.DEEPSLATE_TITANIUM_ORE.method_9564())),
            3));

        // Weed patch - random flower-like patch on grass
        register(context, WEED_PATCH_KEY, class_3031.field_21219, new class_4638(
            50, // tries (20-50 сорняков)
            6,  // xz spread
            2,  // y spread
            class_6817.method_40366(class_3031.field_13518,
                new class_3175(class_4651.method_38432(ModBlocks.WEED)))
        ));

        // Hogweed (Борщевик) patch - использует нашу кастомную Feature
        register(context, HOGWEED_PATCH_KEY, ModFeatures.HOGWEED, class_3111.field_24894);
    }

    public static class_5321<class_2975<?, ?>> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41239, class_2960.method_60655(Caveborn.MOD_ID, name));
    }

    private static <FC extends class_3037, F extends class_3031<FC>> void register(
            class_7891<class_2975<?, ?>> context, class_5321<class_2975<?, ?>> key, 
            F feature, FC config) {
        context.method_46838(key, new class_2975<>(feature, config));
    }
}
