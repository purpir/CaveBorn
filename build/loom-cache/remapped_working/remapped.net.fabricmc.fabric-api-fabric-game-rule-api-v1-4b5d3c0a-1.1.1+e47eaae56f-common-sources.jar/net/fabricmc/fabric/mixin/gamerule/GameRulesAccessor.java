/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.gamerule;

import java.util.Map;
import net.minecraft.world.rule.GameRules;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(GameRules.class)
public interface GameRulesAccessor {
	@Invoker("register")
	static <T extends GameRules.class_4315<T>> GameRules.class_4313<T> callRegister(String name, GameRules.class_5198 category, GameRules.class_4314<T> type) {
		throw new AssertionError("This shouldn't happen!");
	}

	@Accessor("RULE_TYPES")
	static Map<GameRules.class_4313<?>, GameRules.class_4314<?>> getRuleTypes() {
		throw new AssertionError("This shouldn't happen!");
	}
}
